<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($data->config['site_name'] ?? ""); ?> | <?php echo e($data->config['tag']); ?> </title>
    <link rel="stylesheet" href="<?php echo e(asset('public/css/app.css')); ?>">

    
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>

</head>
<body class="bg-gray-900">
    
    

    
    <?php echo $__env->yieldContent('template_content'); ?>
    
    <?php echo $__env->make('client.views.layouts.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\shantricev3\resources\views/client/views/layouts/base.blade.php ENDPATH**/ ?>