$( function() {
    $( "#tabs" ).tabs();
  } );

