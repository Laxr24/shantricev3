<footer>
    <div class=" grid md:grid-cols-3 grid-cols-1 bg-gray-800 px-4 py-24 mt-10 text-gray-200 font-mono tracking-2xl">
        
        <div>
            <p class="text-center text-2xl text-pink-500" >About</p>
            <ul>
                <li class="text-center my-2 "><a class=" transition-all hover:text-purple-600" href="#">CV</a></li>
                <li class="text-center my-2 "><a class=" transition-all hover:text-purple-600" href="#">Deals</a></li>
                <li class="text-center my-2 "><a class=" transition-all hover:text-purple-600" href="#">Meating</a></li>
            </ul>
        </div>
        <div>
            <p class="text-center text-2xl text-pink-500" >Quick links</p>
            <ul>
                <li class="text-center my-2 "><a class=" transition-all hover:text-purple-600" href="#">Timeline</a></li>
                <li class="text-center my-2 "><a class=" transition-all hover:text-purple-600" href="#">Projects</a></li>
                <li class="text-center my-2 "><a class=" transition-all hover:text-purple-600" href="#">Researchs</a></li>
            </ul>
        </div>
        <div>
            <p class="text-center text-2xl text-pink-500" >Deals</p>
            <ul>
                <li class="text-center my-2 "><a class=" transition-all hover:text-purple-600" href="#">Hardware</a></li>
                <li class="text-center my-2 "><a class=" transition-all hover:text-purple-600" href="#">Software</a></li>
                <li class="text-center my-2 "><a class=" transition-all hover:text-purple-600" href="#">Tools</a></li>
            </ul>
        </div>
        
    </div>



    <p class="text-sm text-center p-3 bg-gray-600 text-gray-300 uppercase tracking-3xl">&copy; shantrice 2021</p>
</footer>